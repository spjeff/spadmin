**Project Description**
Allows for multiple import/export of *.csv files to a given term group in SharePoint 2010 Term Store. 

Like my Work? Find this project useful?
![By Me a Beer](Home_buy-me-a-beer-button.jpg|https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CN9XAAGQ4MAFY)


**NEW**: added option to select between multiple metadata application services

![](Home_mms.PNG)

Import: It will create new term group based on the name provided. If group already exist, it will delete all term sets and re-imports from *csv files.

![](Home_import.png)

Export: Will Export each termSet from a given Group to a separate .csv file.

![](Home_export.png)